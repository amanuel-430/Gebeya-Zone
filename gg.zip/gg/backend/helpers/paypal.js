const paypal = require("paypal-rest-sdk");

paypal.configure({
  mode: "sandbox",
  client_id: "ARPgPBAST0EjKNMUyLXaHZB-Zzt-BuwdIHM0agpOaxCrzlbeEscmLSe8VY5XImX2Uz9aa2YdXdbnHVMZ",
  client_secret: "EFlBnbQhbCQX1k_sXL09FYUnHl6-16LanpdD8EXPVMVZE2jdwe6fg0XmbtiHACLosL1X_cqASPugy2hY",
});

module.exports = paypal;