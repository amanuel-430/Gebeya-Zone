 
const express = require("express");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");
const authRouter = require("./routes/auth/auth-routes");
const adminProductsRouter = require("./routes/admin/products-routes");
const adminOrderRouter = require("./routes/admin/order-routes");
const shopProductsRouter = require("./routes/shop/products-routes");
const shopCartRouter = require("./routes/shop/cart-routes");
const shopAddressRouter = require("./routes/shop/address-routes");
const shopOrderRouter = require("./routes/shop/order-routes");
const shopSearchRouter = require("./routes/shop/search-routes");
const shopReviewRouter = require("./routes/shop/review-routes");
const commonFeatureRouter = require("./routes/common/feature-routes");
const notificationRouter = require("./routes/admin/notification-routes");
const adminUserRouter = require("./routes/admin/user-routes");
const statisticsRouter = require("./routes/admin/statistics-routes");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:5173", "http://localhost:5174"],
    methods: ["GET", "POST", "DELETE", "PUT"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  },
  path: "/socket.io/", // Explicitly set path
});

// Secure Socket.IO with JWT
io.use((socket, next) => {
  const token = socket.handshake.auth.token || socket.handshake.headers.cookie?.match(/token=([^;]+)/)?.[1];
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.CLIENT_SECRET_KEY || "CLIENT_SECRET_KEY");
      if (decoded.role === "admin") {
        socket.user = decoded;
        next();
      } else {
        next(new Error("Unauthorized: Admin access required"));
      }
    } catch (err) {
      next(new Error("Unauthorized: Invalid token"));
    }
  } else {
    next(new Error("Unauthorized: No token provided"));
  }
});

app.use(
  cors({
    origin: ["http://localhost:5173", "http://localhost:5174"],
    methods: ["GET", "POST", "DELETE", "PUT"],
    allowedHeaders: ["Content-Type", "Authorization", "Cache-Control", "Expires", "Pragma"],
    credentials: true,
  })
);

app.use(cookieParser());
app.use(express.json());
app.use("/api/auth", authRouter);
app.use("/api/admin/products", adminProductsRouter);
app.use("/api/admin/orders", adminOrderRouter);
app.use("/api/shop/products", shopProductsRouter);
app.use("/api/shop/cart", shopCartRouter);
app.use("/api/shop/address", shopAddressRouter);
app.use("/api/shop/order", shopOrderRouter);
app.use("/api/shop/search", shopSearchRouter);
app.use("/api/shop/review", shopReviewRouter);
app.use("/api/common/feature", commonFeatureRouter);
app.use("/api/admin/notifications", notificationRouter);
app.use("/api/admin/users", adminUserRouter);
app.use("/api/admin/statistics", statisticsRouter);


// WebSocket connection
io.on("connection", (socket) => {
  console.log("Admin connected:", socket.user.userName, socket.id);
  socket.on("disconnect", () => {
    console.log("Admin disconnected:", socket.user.userName, socket.id);
  });
});

mongoose
  .connect(process.env.MONGO_URI || "mongodb+srv://gzon2:mftasssb2@cluster10.vlavkf0.mongodb.net/")
  .then(() => console.log("MongoDB connected"))
  .catch((error) => console.log(error));

server.listen(process.env.PORT || 5000, () =>
  console.log(`Server is now running on port ${process.env.PORT || 5000}`)
);

module.exports = { io };