
// const bcrypt = require("bcryptjs");
// const jwt = require("jsonwebtoken");
// const User = require("../../models/User");

// //register
// const registerUser = async (req, res) => {
//   const { userName, email, password } = req.body;

//   try {
//     const checkUser = await User.findOne({ email });
//     if (checkUser)
//       return res.json({
//         success: false,
//         message: "User already exists with the same email! Please try again",
//       });

//     const hashPassword = await bcrypt.hash(password, 12);
//     const newUser = new User({
//       userName,
//       email,
//       password: hashPassword,
//     });

//     await newUser.save();
//     res.status(200).json({
//       success: true,
//       message: "Registration successful",
//     });
//   } catch (e) {
//     console.log(e);
//     res.status(500).json({
//       success: false,
//       message: "Some error occured",
//     });
//   }
// };


// //login
// const loginUser = async (req, res) => {
//     const { email, password } = req.body;
  
//     try {
//       const checkUser = await User.findOne({ email });
//       if (!checkUser)
//         return res.json({
//           success: false,
//           message: "User doesn't exists! Please register first",
//         });
  
//       const checkPasswordMatch = await bcrypt.compare(
//         password,
//         checkUser.password
//       );
//       if (!checkPasswordMatch)
//         return res.json({
//           success: false,
//           message: "Incorrect password! Please try again",
//         });
  
//       const token = jwt.sign(
//         {
//           id: checkUser._id,
//           role: checkUser.role,
//           email: checkUser.email,
//           userName: checkUser.userName,
//         },
//         "CLIENT_SECRET_KEY",
//         { expiresIn: "60m" }
//       );
  
//       res.cookie("token", token, { httpOnly: true, secure: false }).json({
//         success: true,
//         message: "Logged in successfully",
//         user: {
//           email: checkUser.email,
//           role: checkUser.role,
//           id: checkUser._id,
//           userName: checkUser.userName,
//         },
//       });
//     } catch (e) {
//       console.log(e);
//       res.status(500).json({
//         success: false,
//         message: "Some error occured",
//       });
//     }
//   };

//   //logout
//   const logoutUser = (req, res) => {
//     res.clearCookie("token").json({
//       success: true,
//       message: "Logged out successfully!",
//     });
//   };

// //auth middleware
// const authMiddleware = async (req, res, next) => {
//   const token = req.cookies.token;
//   if (!token)
//     return res.status(401).json({
//       success: false,
//       message: "Unauthorised user!",
//     });
//   try {
//     const decoded = jwt.verify(token, "CLIENT_SECRET_KEY");
//     req.user = decoded;
//     next();
//   } catch (error) {
//     res.status(401).json({
//       success: false,
//       message: "Unauthorised user!",
//     });
//   }
  
// };


// module.exports = { registerUser, loginUser  , logoutUser, authMiddleware };


const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../../models/User");
const Notification = require("../../models/notification");
const { io } = require("../../server");

// Register
const registerUser = async (req, res) => {
  const { userName, email, password } = req.body;

  try {
    // Input validation
    if (!userName || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    const checkUser = await User.findOne({ email });
    if (checkUser) {
      return res.status(400).json({
        success: false,
        message: "User already exists with the same email! Please try again",
      });
    }

    const hashPassword = await bcrypt.hash(password, 12);
    const newUser = new User({
      userName,
      email,
      password: hashPassword,
      role: "user",
    });

    await newUser.save();

    // Save notification
    const notification = await Notification.create({
      message: `New user joined: ${newUser.userName}`,
      type: "user",
      timestamp: new Date(),
    });

    // Emit WebSocket event
    io.emit("notification", notification);

    return res.status(201).json({
      success: true,
      message: "Registration successful",
      user: {
        userName: newUser.userName,
        email: newUser.email,
        role: newUser.role,
      },
    });
  } catch (e) {
    console.error("Registration error:", e); // Detailed error logging
    return res.status(500).json({
      success: false,
      message: "Server error during registration",
      error: e.message,
    });
  }
};

// Login
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    const checkUser = await User.findOne({ email });
    if (!checkUser) {
      return res.json({
        success: false,
        message: "User doesn't exist! Please register first",
      });
    }

    const checkPasswordMatch = await bcrypt.compare(password, checkUser.password);
    if (!checkPasswordMatch) {
      return res.json({
        success: false,
        message: "Incorrect password! Please try again",
      });
    }

    const token = jwt.sign(
      {
        id: checkUser._id,
        role: checkUser.role,
        email: checkUser.email,
        userName: checkUser.userName,
      },
      process.env.CLIENT_SECRET_KEY || "CLIENT_SECRET_KEY",
      { expiresIn: "60m" }
    );

    res.cookie("token", token, { httpOnly: true, secure: false }).json({
      success: true,
      message: "Logged in successfully",
      user: {
        email: checkUser.email,
        role: checkUser.role,
        id: checkUser._id,
        userName: checkUser.userName,
      },
    });
  } catch (e) {
    console.error("Login error:", e);
    res.status(500).json({
      success: false,
      message: "Server error during login",
      error: e.message,
    });
  }
};

// Logout
const logoutUser = (req, res) => {
  try {
    res.clearCookie("token").json({
      success: true,
      message: "Logged out successfully!",
    });
  } catch (e) {
    console.error("Logout error:", e);
    res.status(500).json({
      success: false,
      message: "Server error during logout",
      error: e.message,
    });
  }
};

// Auth Middleware
const authMiddleware = async (req, res, next) => {
  const token = req.cookies.token;
  if (!token) {
    return res.status(401).json({
      success: false,
      message: "Unauthorized user!",
    });
  }
  try {
    const decoded = jwt.verify(token, process.env.CLIENT_SECRET_KEY || "CLIENT_SECRET_KEY");
    req.user = decoded;
    next();
  } catch (error) {
    console.error("Auth middleware error:", error);
    res.status(401).json({
      success: false,
      message: "Unauthorized user!",
      error: error.message,
    });
  }
};

module.exports = { registerUser, loginUser, logoutUser, authMiddleware };