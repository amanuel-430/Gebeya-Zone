
// import { AlignJustify, LogOut, Bell } from "lucide-react"; // Added Bell icon
// import { Button } from "../ui/button";
// import { useDispatch } from "react-redux";
// import { logoutUser } from "@/store/auth-slice";

// function AdminHeader({ setOpen }) {
//   const dispatch = useDispatch();

//   function handleLogout() {
//     dispatch(logoutUser());
//   }

//   return (
//     <header className="flex items-center justify-between px-4 py-3 bg-background border-b">
//       <Button onClick={() => setOpen(true)} className="lg:hidden sm:block">
//         <AlignJustify />
//         <span className="sr-only">Toggle Menu</span>
//       </Button>
//       <div className="flex flex-1 justify-end gap-4"> {/* Added gap for spacing */}
//         {/* Notification Button */}
//         <Button
//           className="inline-flex gap-2 items-center rounded-md px-4 py-2 text-sm font-medium shadow"
//         >
//           <Bell />
//           <span className="sr-only">Notifications</span>
//         </Button>

//         {/* Logout Button */}
//         <Button
//           onClick={handleLogout}
//           className="inline-flex gap-2 items-center rounded-md px-4 py-2 text-sm font-medium shadow"
//         >
//           <LogOut />
//           Logout
//         </Button>
//       </div>
//     </header>
//   );
// }

// export default AdminHeader;


import { AlignJustify, LogOut, Bell } from "lucide-react";
import { Button } from "../ui/button";
import { useDispatch } from "react-redux";
import { logoutUser } from "@/store/auth-slice";
import { useEffect, useState } from "react";
import io from "socket.io-client";
import Cookies from "js-cookie";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const socket = io("http://localhost:5000", {
  withCredentials: true, // Send cookies with Socket.IO
  auth: {
    token: Cookies.get("token"), // Explicitly send JWT token
  },
});

function AdminHeader({ setOpen }) {
  const dispatch = useDispatch();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    // Fetch unread notifications on mount
    fetch("http://localhost:5000/api/admin/notifications/unread", {
      credentials: "include",
    })
      .then((res) => res.json())
      .then((data) => {
        setNotifications(data);
        setUnreadCount(data.length);
      })
      .catch((err) => console.error("Error fetching notifications:", err));

    // Listen for real-time notifications
    socket.on("notification", (notification) => {
      toast.info(notification.message);
      setNotifications((prev) => [notification, ...prev]);
      setUnreadCount((prev) => prev + 1);
    });

    // Handle Socket.IO errors
    socket.on("connect_error", (err) => {
      console.error("Socket.IO connection error:", err.message);
    });

    // Cleanup
    return () => {
      socket.off("notification");
      socket.off("connect_error");
    };
  }, []);

  function handleLogout() {
    dispatch(logoutUser());
  }

  const markAsRead = async () => {
    try {
      await fetch("http://localhost:5000/api/admin/notifications/mark-read", {
        method: "PUT",
        credentials: "include",
      });
      setUnreadCount(0);
      setNotifications((prev) =>
        prev.map((notif) => ({ ...notif, read: true }))
      );
    } catch (err) {
      console.error("Error marking notifications as read:", err);
    }
  };

  return (
    <header className="flex items-center justify-between px-4 py-3 bg-background border-b">
      <Button onClick={() => setOpen(true)} className="lg:hidden sm:block">
        <AlignJustify />
        <span className="sr-only">Toggle Menu</span>
      </Button>
      <div className="flex flex-1 justify-end gap-4">
        {/* Notification Button with Dropdown */}
        <div className="relative">
          <Button
            className="inline-flex gap-2 items-center rounded-md px-4 py-2 text-sm font-medium shadow"
            onClick={() => setShowDropdown(!showDropdown)}
          >
            <Bell />
            {unreadCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full px-2 py-1 text-xs">
                {unreadCount}
              </span>
            )}
            <span className="sr-only">Notifications</span>
          </Button>
          {showDropdown && (
            <div className="absolute right-0 mt-2 w-80 bg-white shadow-lg rounded-md border z-10">
              <div className="p-2 border-b flex justify-between items-center">
                <span className="font-medium">Notifications</span>
                {unreadCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={markAsRead}>
                    Mark all as read
                  </Button>
                )}
              </div>
              {notifications.length > 0 ? (
                notifications.map((notif) => (
                  <div
                    key={notif._id}
                    className={`p-3 border-b ${
                      notif.read ? "bg-gray-100" : "bg-white"
                    }`}
                  >
                    <p className="text-sm">{notif.message}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(notif.timestamp).toLocaleString()}
                    </p>
                  </div>
                ))
              ) : (
                <div className="p-3 text-sm text-gray-500">
                  No notifications
                </div>
              )}
            </div>
          )}
        </div>

        {/* Logout Button */}
        <Button
          onClick={handleLogout}
          className="inline-flex gap-2 items-center rounded-md px-4 py-2 text-sm font-medium shadow"
        >
          <LogOut />
          Logout
        </Button>
      </div>
      <ToastContainer position="top-right" autoClose={3000} />
    </header>
  );
}

export default AdminHeader;

