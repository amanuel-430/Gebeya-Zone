const Notification = require('../../models/notification');

const getUnreadNotifications = async (req, res) => {
  try {
    const notifications = await Notification.find({ read: false }).sort({ timestamp: -1 });
    res.status(200).json(notifications);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const markNotificationsAsRead = async (req, res) => {
  try {
    await Notification.updateMany({ read: false }, { read: true });
    res.status(200).json({ message: 'Notifications marked as read' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = { getUnreadNotifications, markNotificationsAsRead };