const cloudinary = require("cloudinary").v2;
const multer = require("multer");

cloudinary.config({
  cloud_name:"dlq361ryj",
  api_key: "866213397121525",
  api_secret: "LeXi2Tk0mdhKkIpDLBFQoIKbtbU",
});

const storage = new multer.memoryStorage();

async function imageUploadUtil(file) {
  const result = await cloudinary.uploader.upload(file, {
    resource_type: "auto",
  });

  return result;
}

const upload = multer({ storage });
 
module.exports = { upload, imageUploadUtil };