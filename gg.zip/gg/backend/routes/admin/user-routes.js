const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../../controllers/auth/auth-controller');
const {
    getAllUsers,
    updateUserRole,
    blockUser,
    deleteUser
} = require('../../controllers/admin/user-controller');

// Apply auth middleware to all routes
router.use(authMiddleware);

// Get all users
router.get('/', getAllUsers);

// Update user role
router.put('/:userId/role', updateUserRole);

// Block/Unblock user
router.put('/:userId/block', blockUser);

// Delete user
router.delete('/:userId', deleteUser);

module.exports = router; 