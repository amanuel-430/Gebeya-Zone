   const User = require('../../models/User');
   const Product = require('../../models/product');
   const Order = require('../../models/Order');

   const getStatistics = async (req, res) => {
       try {
           // Fetch counts from the database
           const totalUsers = await User.countDocuments();
           const totalProducts = await Product.countDocuments();
           const placedOrders = await Order.countDocuments();
           const soldProducts = await Order.aggregate([
               { $unwind: '$items' },
               { $group: { _id: null, totalSold: { $sum: '$items.quantity' } } }
           ]);

           res.status(200).json({
               success: true,
               statistics: {
                   totalUsers,
                   totalProducts,
                   placedOrders,
                   soldProducts: soldProducts.length > 0 ? soldProducts[0].totalSold : 0
               }
           });
       } catch (error) {
           console.error('Error fetching statistics:', error);
           res.status(500).json({
               success: false,
               message: 'Error fetching statistics'
           });
       }
   };

   module.exports = {
       getStatistics
   };