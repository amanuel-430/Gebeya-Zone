import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
  isLoading: false,
  featureImageList: [],
};

export const getFeatureImages = createAsyncThunk(
  "/order/getFeatureImages",
  async () => {
    const response = await axios.get(
      `http://localhost:5000/api/common/feature/get`
    );

    return response.data;
  }
);

export const addFeatureImage = createAsyncThunk(
  "/order/addFeatureImage",
  async (image) => {
    const response = await axios.post(
      `http://localhost:5000/api/common/feature/add`,
      { image }
    );

    return response.data;
  }
);

const commonSlice = createSlice({
  name: "commonSlice",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getFeatureImages.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getFeatureImages.fulfilled, (state, action) => {
        state.isLoading = false;
        state.featureImageList = action.payload.data;
      })
      .addCase(getFeatureImages.rejected, (state) => {
        state.isLoading = false;
        state.featureImageList = [];
      });
  },
});

export default commonSlice.reducer;



// import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
// import axios from "axios";

// const initialState = {
//   isLoading: false,
//   featureImageList: [],
// };

// // Fetch feature images
// export const getFeatureImages = createAsyncThunk(
//   "/order/getFeatureImages",
//   async () => {
//     const response = await axios.get(
//       `http://localhost:8000/api/common/feature/get`
//     );
//     return response.data;
//   }
// );

// // Add feature image
// export const addFeatureImage = createAsyncThunk(
//   "/order/addFeatureImage",
//   async (image) => {
//     const response = await axios.post(
//       `http://localhost:8000/api/common/feature/add`,
//       { image }
//     );
//     return response.data;
//   }
// );

// // Delete feature image
// export const deleteFeatureImage = createAsyncThunk(
//   "/order/deleteFeatureImage",
//   async (imageId, { rejectWithValue }) => {
//     try {
//       const response = await axios.delete(
//         `http://localhost:8000/api/common/feature/delete/${imageId}`
//       );
//       return response.data; // Return the response data (or just imageId if that's what's needed)
//     } catch (error) {
//       return rejectWithValue(error.response.data); // Return error if the deletion fails
//     }
//   }
// );

// const commonSlice = createSlice({
//   name: "commonSlice",
//   initialState,
//   reducers: {},
//   extraReducers: (builder) => {
//     builder
//       // Handle get feature images
//       .addCase(getFeatureImages.pending, (state) => {
//         state.isLoading = true;
//       })
//       .addCase(getFeatureImages.fulfilled, (state, action) => {
//         state.isLoading = false;
//         state.featureImageList = action.payload.data;
//       })
//       .addCase(getFeatureImages.rejected, (state) => {
//         state.isLoading = false;
//         state.featureImageList = [];
//       })
//       // Handle add feature image
//       .addCase(addFeatureImage.fulfilled, (state, action) => {
//         // Optionally add the new image to the list
//         state.featureImageList.push(action.payload.data);
//       })
//       // Handle delete feature image
//       .addCase(deleteFeatureImage.fulfilled, (state, action) => {
//         // Remove the deleted image from the list
//         state.featureImageList = state.featureImageList.filter(
//           (image) => image.id !== action.payload.id
//         );
//       })
//       .addCase(deleteFeatureImage.rejected, (state, action) => {
//         // Handle error during deletion if necessary
//         console.error("Error deleting image:", action.payload);
//       });
//   },
// });

// export default commonSlice.reducer;
