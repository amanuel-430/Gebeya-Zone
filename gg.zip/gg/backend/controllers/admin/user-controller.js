const User = require('../../models/User');

// Get all users
const getAllUsers = async (req, res) => {
    try {
        console.log('getAllUsers called, user:', req.user); // Debug log

        // Check if the requesting user is an admin
        if (!req.user || req.user.role !== 'admin') {
            console.log('Access denied - User:', req.user); // Debug log
            return res.status(403).json({
                success: false,
                message: 'Access denied. Admin privileges required.'
            });
        }

        const users = await User.find({}, { password: 0 }); // Exclude password from results
        console.log('Found users:', users.length); // Debug log

        res.status(200).json({
            success: true,
            users
        });
    } catch (error) {
        console.error('Error in getAllUsers:', error); // More detailed error logging
        res.status(500).json({
            success: false,
            message: 'Error fetching users',
            error: error.message // Include error message in response
        });
    }
};

// Update user role
const updateUserRole = async (req, res) => {
    try {
        // Check if the requesting user is an admin
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Access denied. Admin privileges required.'
            });
        }

        const { userId } = req.params;
        const { role } = req.body;

        // Validate role
        if (!['admin', 'user'].includes(role)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid role specified'
            });
        }

        const user = await User.findByIdAndUpdate(
            userId,
            { role },
            { new: true, select: '-password' }
        );

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.status(200).json({
            success: true,
            message: 'User role updated successfully',
            user
        });
    } catch (error) {
        console.error('Error updating user role:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating user role'
        });
    }
};

// Block/Unblock user
const blockUser = async (req, res) => {
    try {
        // Check if the requesting user is an admin
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Access denied. Admin privileges required.'
            });
        }

        const { userId } = req.params;
        const { isBlocked } = req.body;

        const user = await User.findByIdAndUpdate(
            userId,
            { isBlocked },
            { new: true, select: '-password' }
        );

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.status(200).json({
            success: true,
            message: isBlocked ? 'User blocked successfully' : 'User unblocked successfully',
            user
        });
    } catch (error) {
        console.error('Error updating user block status:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating user block status'
        });
    }
};

// Delete user
const deleteUser = async (req, res) => {
    try {
        // Check if the requesting user is an admin
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Access denied. Admin privileges required.'
            });
        }

        const { userId } = req.params;

        const user = await User.findByIdAndDelete(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.status(200).json({
            success: true,
            message: 'User deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({
            success: false,
            message: 'Error deleting user'
        });
    }
};

module.exports = {
    getAllUsers,
    updateUserRole,
    blockUser,
    deleteUser
}; 