// const AdminUsers = () => {
//   return (
//     <div>
//       <h1>Admin Users</h1>
//       <p>This is users page.</p>
//     </div>
//   );
// }
// export default AdminUsers;

import { useEffect, useState } from "react";
import axios from "axios";
import { useToast } from "@/components/ui/use-toast";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MoreHorizontal, Search } from "lucide-react";

const AdminUsers = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState("");
    const { toast } = useToast();
    const { user, isAuthenticated } = useSelector((state) => state.auth);
    const navigate = useNavigate();

    useEffect(() => {
        console.log('Auth State:', { isAuthenticated, user }); // Debug auth state

        // Check if user is authenticated and is an admin
        if (!isAuthenticated || user?.role !== 'admin') {
            console.log('Access denied - Not authenticated or not admin'); // Debug access check
            toast({
                title: "Access Denied",
                description: "You must be an admin to access this page",
                variant: "destructive",
            });
            navigate('/unauth-page');
            return;
        }

        fetchUsers();
    }, [isAuthenticated, user, navigate, toast]);

    const fetchUsers = async () => {
        try {
            console.log('Fetching users...'); // Debug API call
            const response = await axios.get("http://localhost:5000/api/admin/users", {
                withCredentials: true,
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            console.log('API Response:', response.data); // Debug API response
            if (response.data.success) {
                setUsers(response.data.users);
            }
        } catch (error) {
            console.error('Error fetching users:', error);
            console.error('Error details:', {
                status: error.response?.status,
                statusText: error.response?.statusText,
                data: error.response?.data,
                headers: error.response?.headers
            });
            toast({
                title: "Error fetching users",
                description: error.response?.data?.message || "Something went wrong",
                variant: "destructive",
            });
        } finally {
            setLoading(false);
        }
    };

    const handleRoleChange = async (userId, newRole) => {
        try {
            const response = await axios.put(
                `http://localhost:5000/api/admin/users/${userId}/role`,
                { role: newRole },
                { withCredentials: true }
            );
            if (response.data.success) {
                toast({
                    title: "Role updated successfully",
                });
                fetchUsers(); // Refresh the user list
            }
        } catch (error) {
            toast({
                title: "Error updating role",
                description: error.response?.data?.message || "Something went wrong",
                variant: "destructive",
            });
        }
    };

    const handleBlockUser = async (userId, isBlocked) => {
        try {
            const response = await axios.put(
                `http://localhost:5000/api/admin/users/${userId}/block`,
                { isBlocked },
                { withCredentials: true }
            );
            if (response.data.success) {
                toast({
                    title: isBlocked ? "User blocked successfully" : "User unblocked successfully",
                });
                fetchUsers(); // Refresh the user list
            }
        } catch (error) {
            toast({
                title: "Error updating user status",
                description: error.response?.data?.message || "Something went wrong",
                variant: "destructive",
            });
        }
    };

    const handleDeleteUser = async (userId) => {
        if (!window.confirm("Are you sure you want to delete this user?")) return;

        try {
            const response = await axios.delete(
                `http://localhost:5000/api/admin/users/${userId}`,
                { withCredentials: true }
            );
            if (response.data.success) {
                toast({
                    title: "User deleted successfully",
                });
                fetchUsers(); // Refresh the user list
            }
        } catch (error) {
            toast({
                title: "Error deleting user",
                description: error.response?.data?.message || "Something went wrong",
                variant: "destructive",
            });
        }
    };

    const filteredUsers = users.filter((user) =>
        user.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">User Management</h1>
                <div className="relative w-64">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Search users..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-8"
                    />
                </div>
            </div>

            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {filteredUsers.map((user) => (
                        <TableRow key={user._id}>
                            <TableCell>{user.userName}</TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>{user.role}</TableCell>
                            <TableCell>
                                <span
                                    className={`px-2 py-1 rounded-full text-xs ${
                                        user.isBlocked
                                            ? "bg-red-100 text-red-800"
                                            : "bg-green-100 text-green-800"
                                    }`}
                                >
                                    {user.isBlocked ? "Blocked" : "Active"}
                                </span>
                            </TableCell>
                            <TableCell className="text-right">
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" className="h-8 w-8 p-0">
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                        <DropdownMenuItem
                                            onClick={() => handleRoleChange(user._id, "admin")}
                                            disabled={user.role === "admin"}
                                        >
                                            Make Admin
                                        </DropdownMenuItem>
                                        <DropdownMenuItem
                                            onClick={() => handleRoleChange(user._id, "user")}
                                            disabled={user.role === "user"}
                                        >
                                            Make User
                                        </DropdownMenuItem>
                                        <DropdownMenuItem
                                            onClick={() => handleBlockUser(user._id, !user.isBlocked)}
                                        >
                                            {user.isBlocked ? "Unblock User" : "Block User"}
                                        </DropdownMenuItem>
                                        <DropdownMenuItem
                                            onClick={() => handleDeleteUser(user._id)}
                                            className="text-red-600"
                                        >
                                            Delete User
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
};

export default AdminUsers;