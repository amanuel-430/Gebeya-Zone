
import { useEffect, useState } from "react";
import axios from "axios";
import { Card, CardContent, CardHeader, CardTitle } from "@/components//ui/card";

function AdminDashboard() {
  const [statistics, setStatistics] = useState({
    totalUsers: 0,
    soldProducts: 0,
    placedOrders: 0,
    totalProducts: 0,
  });

  useEffect(() => {
    const fetchStatistics = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/admin/statistics", {
          withCredentials: true,
        });
        if (response.data.success) {
          setStatistics(response.data.statistics);
        }
      } catch (error) {
        console.error('Error fetching statistics:', error);
      }
    };

    fetchStatistics();
  }, []);

  return (
    <div>
    <div className="flex flex-col gap-4">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{statistics.totalUsers}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Sold Products</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{statistics.soldProducts}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Placed Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{statistics.placedOrders}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total Products</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{statistics.totalProducts}</p>
          </CardContent>
        </Card>
      </div>
      
    </div>
    
    </div>
  );
}

export default AdminDashboard;

 