const UnauthPage = () => {
    return (
        <h3>You dont have access to this page</h3>
    )
}
export default UnauthPage