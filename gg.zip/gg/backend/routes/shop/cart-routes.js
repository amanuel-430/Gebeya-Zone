const express = require("express");

const {
  addToCart,
  fetchCartItems,
  deleteCartItem,
  updateCartItemQty,
} = require("../../controllers/shop/cart-controller");

const router = express.Router();

router.post("/add", addToCart);
router.get("/get/:userId", fetchCartItems);
router.put("/update-cart", updateCartItemQty);
router.delete("/:userId/:productId", deleteCartItem);

module.exports = router;

// const express = require("express");
// const {
//   addToCart,
//   fetchCartItems,
//   deleteCartItem,
//   updateCartItemQty,
// } = require("../../controllers/shop/cart-controller");

// const router = express.Router();

// // POST route to add an item to the cart
// router.post("/add", addToCart);

// // GET route to fetch all items in the cart
// router.get("/get/:userId", fetchCartItems);

// // PUT route to update quantity of an item in the cart
// router.put("/update-cart", updateCartItemQty);

// // DELETE route to remove an item from the cart
// router.delete("/:userId/:productId", deleteCartItem);

// module.exports = router;
