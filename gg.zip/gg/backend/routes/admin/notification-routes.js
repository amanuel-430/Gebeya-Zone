const express = require('express');
const router = express.Router();
const {
  getUnreadNotifications,
  markNotificationsAsRead,
} = require('../../controllers/admin/notification-controller');

router.get('/unread', getUnreadNotifications);
router.put('/mark-read', markNotificationsAsRead);

module.exports = router;