const NotFound = () => {
    return (
        <div>page does not exist</div>
    );
}
export default NotFound;